# Changelog

## 0.10.0 (Dezember 15, 2015)

### Changed
- Switched to Vuejs 1.0

## 0.9.3 (October 30, 2015)

### Changed
- Date is set to "now" on post copy

## 0.9.2 (October 14, 2015)

### Fixed
- Date conversion to ISO8601
- Feed charset

## 0.9.1 (October 8, 2015)

### Added
- Sections tabs in post edit view

### Fixed
- Comments margin
- "Require email" setting
- Display of URLs with UTF8 characters

## 0.9.0 (September 10, 2015)

- Initial release
