<?php foreach ($widgets as $widget) : ?>

    <?= $widget->get('result') ?>

<?php endforeach ?>
